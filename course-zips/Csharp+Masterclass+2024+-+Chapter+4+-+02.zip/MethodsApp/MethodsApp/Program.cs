﻿// Methods are structured like this
// modifier returnType MethodName(Parameters){
// code block
// }

// Definition of a void method that returns nothing
void MyFirstMethod()
{
    Console.WriteLine("MyFirstMethod was called");
    Console.WriteLine("Some super complicated code");
}

// Calling a Method
MyFirstMethod();
MyFirstMethod();
MyFirstMethod();
MyFirstMethod();

Console.WriteLine("This is outside of the method");
Console.ReadKey();

