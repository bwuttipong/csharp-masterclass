﻿namespace InterfacesApp
{   
    public interface IExample
    {
        void Method();
        int Method2(string parameter);
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }


}
