﻿
int num = 0;

Console.WriteLine($"Num is {num}");
// incrementing of int
num++;
Console.WriteLine($"Num is {num}");

// pre-incrementing
Console.WriteLine("Num is {0}", ++num);
Console.WriteLine("Num is {0}", num++);
Console.WriteLine("Num is {0}", num);
Console.ReadLine();