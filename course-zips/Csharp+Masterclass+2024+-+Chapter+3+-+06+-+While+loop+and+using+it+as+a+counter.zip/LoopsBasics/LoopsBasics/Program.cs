﻿// The While Loop


int counter = 0;
while (counter < 10)
{
    Console.WriteLine(counter);
    counter +=5;
}

Console.ReadKey();
